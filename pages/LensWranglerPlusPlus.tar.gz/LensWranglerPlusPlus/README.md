LensWrangler Plus Plus
============

LensWranglerPlusPlus is based on [LensWrangler](http://drphilmarshall.github.com/LensWrangler/) , modified by Nan Li. It involves ellipitical lenses, ellipitical sources and some new images. "eelens.js" in this repository is an updated version of [lens.js](https://github.com/slowe/lensjs), it includes elliptical models of both lenses and sources.

[Example.](http://linan7788626.github.io/pages/LensWranglerPlusPlus/index.html)


-------------
###To-do List

- [x] Export lens models as ASCII files
- [x] Imort lens models from ASCII files
- [x] Upload lensed images interactively
